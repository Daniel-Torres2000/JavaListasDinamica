/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package spotify1;

import javax.swing.JFrame;

/**
 *
 * @author ubuntu
 */
public class Spotify1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        spotify1 a= new spotify1();
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		a.setSize(600, 320);
		a.setVisible(true);
    }
    
}
